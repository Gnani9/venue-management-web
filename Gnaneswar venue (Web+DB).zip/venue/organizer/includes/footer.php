<footer>
    <div class="container">
      <div class="col-lg-8">
        <p>Copyright © 2023-2024 Ltd. All rights reserved. 
        
        <!-- Design: <a rel="nofollow" href="https://templatemo.com" target="_blank">TemplateMo</a> Distribution: <a href="https://themewagon.com">ThemeWagon</a></p> -->
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>

  <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="../assets/js/isotope.min.js"></script>
  <script src="../assets/js/owl-carousel.js"></script>
  <script src="../assets/js/counter.js"></script>
  <script src="../assets/js/custom.js"></script>
  <script type="text/javascript" src="../assets/packages/datatables.js"></script>
  <script type="text/javascript" src="../assets/js/jquery.datetimepicker.full.js"></script>

  <script type="text/javascript" src="../assets/packages/dataTables.altEditor.free.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.js" ></script>
  <script type="text/javascript" src="../assets/js/script.js"></script>

  </body>
</html>